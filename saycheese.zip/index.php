<?php
#index.php for pantiespizza.com
#saycheese theme wp
#version 1.0
?>